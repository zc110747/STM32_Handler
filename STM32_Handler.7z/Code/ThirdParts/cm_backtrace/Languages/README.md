# CmBacktrace: ARM Cortex-M 系列 MCU 错误追踪库

## 多语言支持

| Language             | Location (or type)         | Language tag |
|----------------------|----------------------------|--------------|
| English              | United States              | en-US        |
| Chinese (Simplified) | People's Republic of China | zh-CN        |