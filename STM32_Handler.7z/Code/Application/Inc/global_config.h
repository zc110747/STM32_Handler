
#ifndef _GLOBAL_CONFIG_H
#define _GLOBAL_CONFIG_H

//support font
#define SUPPORT_ASCII_1206              1
#define SUPPORT_ASCII_1608              1
#define SUPPORT_ASCII_2412              1
#define SUPPORT_ASCII_3216              1


#endif
