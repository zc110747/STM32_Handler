
#include "template.hpp"

BaseType_t x_driver::init()
{
    return pdPASS;
}

BaseType_t x_driver::hardware_init()
{
    
}

BaseType_t x_driver::test()
{
    return pdPASS;
}