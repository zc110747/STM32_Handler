
_Pragma("once");

#include "interface.h"

#ifdef __cplusplus
    extern "C"
    {
#endif
        
BaseType_t dsp_app(void);
        
#ifdef __cplusplus
    }
#endif
